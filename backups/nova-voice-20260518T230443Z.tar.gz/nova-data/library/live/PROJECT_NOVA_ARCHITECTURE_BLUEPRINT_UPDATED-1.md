# PROJECT NOVA ARCHITECTURE BLUEPRINT (live reference)

Project Nova: Implementation Blueprint & Technical Architecture

Version: 2.0 Rebuild DirectionPriority: Voice reliability, low latency, and clean rebuild discipline [file:9][file:48]

Core Objective

Build Nova as a voice-first AI system that can handle real customer conversations with low latency, stable interruption handling, and a clean operational foundation on the active DigitalOcean droplet. The rebuild is intentionally narrow: get the voice stack solid before adding broader agent behavior, research tools, or heavier orchestration layers. [file:9][file:48]

1. Infrastructure Foundation

Nova is being rebuilt on a clean DigitalOcean droplet that acts as the primary active workspace. The desktop is not the build environment; it is used for periodic backups and safety copies of important files. [file:9][file:48]

Infrastructure Principles

One clean active droplet as the current rebuild environment. [file:48]

Backups copied off-server regularly for protection, not as the live runtime. [file:48]

Keep the workspace free of legacy broken files and abandoned experiments. [file:48]

Treat clean-state discipline as part of the architecture, not just housekeeping. [file:48]

2. Real-Time Voice Stack

LiveKit is the primary real-time engine for Nova because it supports low-latency streaming, interruption handling, and the kind of human conversational flow the product depends on. OpenAI Realtime is the primary model/runtime path for voice interaction in the current rebuild. [file:9]

Primary Runtime Path

Layer

Current Choice

Role

Real-time transport

LiveKit [file:9]

Handles real-time audio, turn-taking, and interruption flow.

Voice intelligence

OpenAI Realtime [file:9]

Drives live voice interaction as the main production path.

Hosting

DigitalOcean droplet [file:9][file:48]

Runs the clean rebuild environment.

Voice Requirements

Low perceived latency suitable for natural conversation. [file:9]

Immediate interruption handling when the caller speaks over Nova. [file:9]

Stable reconnect behavior after dropped sessions or transport errors. [file:18]

Reliable session persistence and fast restart behavior. [file:18]

3. What Is Not in the Core Rebuild

The rebuild does not use Antigravity as the active framework. The rebuild also does not use Gemini 2.0 as the primary operating model, and it does not include a text-first Nova path for launch. [file:9][file:48]

Exclusions for Phase 1

No Antigravity dependency in the main runtime path. [file:9][file:48]

No Gemini 2.0-first architecture for launch. [file:9][file:48]

No broad multitool sprawl during the voice stabilization phase. [file:48]

No desktop-as-primary-build setup. [file:48]

4. Memory and Session Continuity

Persistent memory and session continuity remain important, especially across restarts. The retained portion of the Grok guidance still applies: preserve conversation history, reload recent context on startup, summarize older context when needed, and recover cleanly from connection failures. [file:18]

Memory Priorities

Save conversation state automatically. [file:18]

Reload recent context after restart. [file:18]

Keep context compact through summarization when needed. [file:18]

Prevent Nova from appearing “gone” after session interruptions. [file:18]

5. Knowledge and Tool Expansion

Additional tools are part of the roadmap, but they come after voice reliability. Firecrawl is reserved for later knowledge ingestion, and Multica is reserved for later operations/workflow support rather than the first core runtime. [file:9][file:13][file:48]

Later Additions

Tool

Planned Role

Timing

Firecrawl

Knowledge ingestion and live information gathering [file:9]

After core voice stability

Multica

Operations workflow, task coordination, and support-side agent activity [file:13]

After core voice stability

Langfuse

Desktop monitoring layer with one project/dashboard per client [web:30][web:43]

As operator oversight becomes necessary

6. Monitoring and Operator View

Multica is not being removed. It remains part of the broader system for operations and workflow. For Ray’s desktop monitoring need, Langfuse is the better companion layer because it supports custom dashboards and a project-based structure that fits the “one client, one page” dashboard model. [file:13][web:30][web:43]

Monitoring Design Direction

One client equals one dashboard or project view. [web:30][web:43]

Ray needs desktop visibility into calls, traces, failures, latency, and system health. [web:30]

Monitoring should support operations without becoming the runtime bottleneck. [web:30][file:13]

7. Agent Architecture Direction

Nova still serves as the top-level orchestration brain in the long-term vision, but the rebuild should not start with a complex spawning hierarchy. The first milestone is a stable receptionist-grade voice agent that can be tested, scored, and trusted. [file:9][file:14][file:48]

Build Order

Stable voice runtime. [file:48]

Reliable receptionist behavior. [file:8][file:48]

Repeatable onboarding flow for one client. [file:8]

Carefully added support tooling. [file:9][file:13]

Broader spawning and workflow automation later. [file:14]

8. Failure Isolation and Scale Direction

The droplet-based model still matters because it supports isolation, cleaner debugging, and safer customer separation. As customer count grows, the system can expand into more isolated deployments and grouped infrastructure, but that is a scale-phase problem, not a day-one rebuild goal. [file:9]

Scale Principles

Isolation reduces cross-client risk. [file:9]

Clean deployments simplify debugging and rollback. [file:9][file:48]

Scale should follow stability, not lead it. [file:48]

9. Immediate Technical Priorities

Priority Order

Confirm the clean droplet is the only active runtime environment. [file:48]

Verify the LiveKit plus OpenAI Realtime voice path works consistently. [file:9][file:48]

Harden memory persistence and reconnect behavior. [file:18]

Stress test real conversation flow, including interruptions and long sessions. [file:8][file:9]

Add later tools only after Nova passes stability gates. [file:9][file:13]

10. Architectural Rule for the Rebuild

Every new addition must answer one question: does this make the voice product more stable right now, or is it a later-layer tool? If it is a later-layer tool, it waits. That rule protects the rebuild from turning back into a mixed pile of half-working systems. [file:48][file:9]