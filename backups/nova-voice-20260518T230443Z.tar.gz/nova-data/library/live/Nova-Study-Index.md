# Nova Study Index (live)

Compact recovery map for schooling and memory. Voice may load this when `NOVA_STUDY_INDEX=1`.

## Core syllabus (repo)

- `complete_syllabus.md` — v5.1 doctorate track (82 subjects)
- `NOVA_EDUCATION_SCRATCHPAD.md` — autonomous schooling PAUSED 2026-05-18 (was 12a, 6a, 12p, 6p — do not schedule)

## Study protocols (nova-data)

- `nova-data/EQ_Study_Protocol.md` — 6-hour EQ cycles
- `nova-data/Reflective_Learning.md` — growth journal
- `nova-data/memory/Memory_Nexus.md` — hand-maintained index

## Autonomy alignment

- `Nova-Capabilities.md` (this folder) — levels 0–10
- `Nova-SOVEREIGN-AUTONOMY-MANIFEST-v2.2.md` — staging tiers

## Dual-study rule

Each cycle: one business subject + one emotional subject. Notebook archive is separate; do not auto-write notebooks from voice until enabled.
