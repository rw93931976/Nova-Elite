# Deprecated — use Nova-Persona-Voice.md

Voice loads: `Nova-Persona-Voice.md` (small slice, instructions-only).

Private full persona: `../Nova-Persona-Instructions-PRIVATE.md` (not loaded on calls).
