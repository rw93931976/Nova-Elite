# Nova live references (voice runtime)

Drop approved sources here. Voice agent reads them when `NOVA_LIVE_REFERENCES=1`.

| Role | Basename | Formats tried (first match wins) |
|------|----------|----------------------------------|
| Policy | `Nova-Decision-Log` | `.md`, `.docx` |
| Runtime / build | `PROJECT_NOVA_ARCHITECTURE_BLUEPRINT_UPDATED-1` | `.md`, `.docx` |
| Identity / vision | `Nova-SOVEREIGN-AUTONOMY-MANIFEST-v2.2` | `.md`, `.txt`, `.docx` |
| Capabilities | `Nova-Capabilities` | `.md`, `.txt`, `.docx` |

Override directory: `NOVA_LIVE_REF_DIR` (default: `{repo}/nova-data/library/live`).
